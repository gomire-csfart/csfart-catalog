Geumgwanggeum 1521 / CSFART / approved catalogue export
Page: https://gomire-csfart.github.io/csfart-catalog/product/geumgwanggeum-1521.html
Price: 150000 KRW, customer SKU: CSFART금광금_1521

01_original_16_jpg: 9 approved 1000x1000 guide JPGs + 7 actual specimen JPGs. Bytes and SHA256 same as published GitHub files; NO EDITS.
02_page_screens: actual published web page captured in browser and split from top to bottom in file order; JPEG screenshots are screen captures, not byte-identical originals.
Note: individual Naver SmartStore product link has not been provided, therefore current page only points to the CSFART store homepage.
